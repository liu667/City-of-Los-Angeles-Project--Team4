library(shiny)
library(shinythemes)
library(lubridate)

ui <- navbarPage(
  theme = shinytheme("paper"),
  title = "City fo Los Angeles Homeless Project",
  
  tabPanel("Introduction",
           fluidPage(
             h1("City of Los Angeles Homeless Overview"),
             tags$blockquote("123"),
             #plain text in paragraph
             p("This is the body."),
             #Single line break
             br(),
             #bold text in paragraph
             tags$b("This is the bold text"),
             div("div creates segments of text with a similar style. 
                 This division of text is all blue because I passed the argument 'style = color:blue' to div",
                 style = "color:blue"),
             
             img(src='homeless.jpg', align = "right"),
             
             
             fluidRow(
               column(6, h3("Title in one row")),
               column(6)
               
             ))),
  
  navbarMenu("Data Analysis",
             
             tabPanel("Homeless Data", fluidPage(
               
               sidebarLayout(
                 sidebarPanel(
                   selectInput(inputId = "dataset",
                               label = "DATASETS",
                               choices = list("By Community", "By Tract"),
                               selected = "By Community")
                 ),
                 mainPanel(leafletOutput("tot_map"))
               )
               
               
             )),
             
             tabPanel("311 Call Data", fluidPage(
               
               sidebarLayout(
                 sidebarPanel(
                   helpText("Create maps with information from 311call dataset."),
                   
                   sliderInput("week", 
                               label = "Week:",
                               min = 1, max = 44, value = 5)
                 ),
                 
                 mainPanel(leafletOutput("call"))
               )
             )),
             
             tabPanel("Crime Data"),
             
             tabPanel("Shelter Data")),
  
  
  tabPanel("Recommendations")
)


server <- function(input, output, session){
  
  datasets <- observe({
    if(input$dataset == "By Community"){
  
      
      renderTable ({total_commu = data_census17_tract %>%
        group_by(CD) %>%
        summarise(Number = sum(totPeople))
      total_commu$CD = as.character(total_commu$CD)
      commu_combine = left_join(community_map, total_commu,
                                by = c("id" = "CD"))
      })
      community1 = distinct(commu_combine, id, Number)
      commuid = community1$id
    
      commupolygons<-lapply(commuid, function(x) polyFunc(x, dat=commu_combine))
      
      commusp.polygon<-SpatialPolygons(commupolygons)
      commudf.polygon<-SpatialPolygonsDataFrame(commusp.polygon,
                                                data=data.frame(row.names=commuid, community1))
      pal <- colorNumeric(
        palette = "Blues",
        domain = commudf.polygon$Number
      )
      
      
      output$tot_map = renderLeaflet({
        
        leaflet()%>%
          addTiles() %>%
          addPolygons(data = commudf.polygon,
                      fillColor = ~pal(Number),
                      color = "#5297A8", 
                      fillOpacity = 0.8, 
                      weight = 1, 
                      smoothFactor = 1)%>%
          addLegend(pal = pal, 
                    values = commudf.polygon$Number, 
                    position = "bottomright", 
                    title = "Number of Homeless People by District")
        
        
      })
    }
    else{
      
      tract_map = fortify(tract_map2,region = "CT10")
      
      tract_map$id = as.numeric(tract_map$id)
      
      ladata = data_census17_tract %>%
        filter(City == "Los Angeles") %>%
        arrange(-totPeople) %>%
        slice(2:1004)
      
      combine = tract_map %>%
        left_join(ladata,
                  by = c("id"="tract")) %>%
        filter(City == "Los Angeles")
      
      
      
      tract_map1 = distinct(combine, id,  totPeople)
      tractid <- tract_map1$id
      
      polyFunc<-function(groupname, dat){
        poly<-filter(dat, id==groupname) %>%
          dplyr::select(long, lat)
        return(Polygons(list(Polygon(poly)), groupname))
      }
      
      polygons<-lapply(tractid, function(x) polyFunc(x, dat=combine))
      
      sp.polygon<-SpatialPolygons(polygons)
      df.polygon<-SpatialPolygonsDataFrame(sp.polygon,
                                           data=data.frame(row.names=tractid, tract_map1))
      pal <- colorNumeric(
        palette = "Blues",
        domain = df.polygon$totPeople
      )
      
      output$tot_map = renderLeaflet({
        leaflet()%>%
        addTiles() %>%
        addPolygons(data = df.polygon,
                    fillColor = ~pal(totPeople),
                    color = "#5297A8", 
                    fillOpacity = 0.8, 
                    weight = 1, 
                    smoothFactor = 1)%>%
        addLegend(pal = pal, 
                  values = df.polygon$totPeople, 
                  position = "bottomright", 
                  title = "Number of Homeless People by Tract")
  })
    }
    
  })
  
  data_311$CREATEDDATE = mdy_hms(data_311$CREATEDDATE)
  data_311$Week = week(data_311$CREATEDDATE)
  
  output$call <- renderLeaflet({
    
    data_week311 = data_311 %>%
      filter(Week == input$week) 
    
    data_week311%>%
      leaflet()%>%  
      addTiles() %>%
      addPolygons(data = community_map1,
                  color = "#c8515f", 
                  fillOpacity = 0.5, 
                  weight = 1, 
                  smoothFactor = 1) %>%
      #setView(zoom = 4) %>%
      addCircleMarkers(lng=data_week311[,23], lat=data_week311[,22],
                       radius = 6, stroke = FALSE, fillOpacity = 0.5)
  })
    
  
  }
  
  
  


shinyApp(ui,server)







