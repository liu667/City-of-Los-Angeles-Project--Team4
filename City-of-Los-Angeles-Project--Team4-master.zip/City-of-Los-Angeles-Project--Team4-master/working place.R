library(ggplot2)
library(dplyr)
library(tidyr)
library(stringr)
library(ggmap)
library(zipcode)
library(lubridate)
library(readxl)
library(leaflet)
library(rgdal)
library(sp)
library(raster)
library(maptools)
library(geojsonio)
library(tmap)

data_311 = read.csv("la_city_independent_analysis/data/311_calls_w_CTs20171102134828.csv")
data_crime = read.csv("la_city_independent_analysis/data/crime_w_CTs20171102134814.csv")
data_shelter = read.csv("la_city_independent_analysis/data/shelters_w_CTs20171102134808.csv")
data_census17_tract = read_excel("la_city_independent_analysis/data/homeless-count-2017-results-by-census-tract.xlsx",
                                 sheet = "Count_by_Tract")
data_census17_community = read_excel("la_city_independent_analysis/data/homeless-count-2017-results-by-census-tract.xlsx",
                                     sheet = "Count_by_Community")

community_map = readOGR("CnclDist_July2012/CnclDist_July2012.shp")
community_map1 = spTransform(community_map, CRS("+proj=longlat +datum=WGS84"))
community_map = fortify(community_map1, region = "DISTRICT")
communitymap = as.data.frame(community_map1)
tract_map = readOGR("la_city_independent_analysis/data/raw_data/CENSUS_TRACTS_2010.zip_unzipped/CENSUS_TRACTS_2010.shp")
tract_map2 = spTransform(tract_map, CRS("+proj=longlat +datum=WGS84"))

polyFunc<-function(groupname, dat){
  poly<-filter(dat, id==groupname) %>%
    dplyr::select(long, lat)
  return(Polygons(list(Polygon(poly)), groupname))
}



data_311$CREATEDDATE = mdy_hms(data_311$CREATEDDATE)
data_311$Week = week(data_311$CREATEDDATE)


  
  data_week311 = data_311 %>%
    filter(Week == "1") 
  
  data_week311%>%
    leaflet()%>%  
    addTiles() %>%
    addPolygons(data = community_map1,
                color = "#c8515f", 
                fillOpacity = 0.5, 
                weight = 1, 
                smoothFactor = 1) %>%
    setView(zoom = 4) %>%
    addCircleMarkers(lng=data_week311[,23], lat=data_week311[,22],
                     radius = 6, stroke = FALSE, fillOpacity = 0.5)











